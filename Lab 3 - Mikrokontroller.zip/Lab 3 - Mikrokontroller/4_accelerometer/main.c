#include <stdint.h>
#include "accel.h"
#include "utility.h"
#include "ubit_led_matrix.h"


int main(){
	

	return 0;
}
