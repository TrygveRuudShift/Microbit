#include <stdint.h>
#include "twi.h"

void twi_init() {
    TWIO->ENABLE = 0x5; //0x5 = enable
    TWIO->FREQUENCY = 0x01980000; //100kbps
    TWIO->PSELSCL = 0; //port for scl
    TWIO->PSELSDA = 30; //port sda
    
}