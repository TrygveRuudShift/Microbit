#ifndef TWI_H
#define TWI_H

void twi_init();

#define TWIO ((NRF_TWI_REG*)0x40003000)

typedef struct {
    // Tasks
    volatile uint32_t STARTRX;
    volatile uint32_t RESERVED_0[0x1];
    volatile uint32_t STARTTX;
    volatile uint32_t RESERVED_1[0x2];
    volatile uint32_t STOP;
    volatile uint32_t RESERVED_2[0x1];
    volatile uint32_t SUSPEND;
    volatile uint32_t RESUME;
    volatile uint32_t RESERVED_3[0x38];
    // Evemts
    volatile uint32_t STOPPED;
    volatile uint32_t RXDREADY;
    volatile uint32_t RESERVED_4[0x4];
    volatile uint32_t TXDSENT;
    volatile uint32_t RESERVED_5[0x1];
    volatile uint32_t ERROR;
    volatile uint32_t RESERVED_6[0x4];
    volatile uint32_t BB;
    volatile uint32_t RESERVED_7[0x31];
    // Registers
    volatile uint32_t SHORTS;
    volatile uint32_t RESERVED_8[0x3f];
    volatile uint32_t INTEN;
    volatile uint32_t INTENSET;
    volatile uint32_t INTENCLR;
    volatile uint32_t RESERVED_9[0x6e];
    volatile uint32_t ERRORSRC;
    volatile uint32_t RESERVED_10[0xe];
    volatile uint32_t ENABLE;
    volatile uint32_t RESERVED_11[0x1];
    volatile uint32_t PSELSCL;
    volatile uint32_t PSELSDA;
    volatile uint32_t RESERVED_12[0x2];
    volatile uint32_t RXD;
    volatile uint32_t TXD;
    volatile uint32_t RESERVED_13[0x1];
    volatile uint32_t FREQUENCY;
    volatile uint32_t RESERVED_14[0x18];
    volatile uint32_t ADDRESS;
} NRF_TWI_REG;

#endif