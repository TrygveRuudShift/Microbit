#ifndef ACCEL_H
#define ACCEL_H

void accel_init();

void accel_read_x_y_z(int * data_buffer);

#endif
